// import { provideRouter } from '@angular/router';
// import { provideHttpClient } from '@angular/http';
// import { routes } from './app.routes';

// export const appConfig: ApplicationConfig = {
//   providers: [
//     provideRouter(routes),
//     provideHttpClient() // Allow the Angular environment to communicate via HTTP
//   ]
// };
